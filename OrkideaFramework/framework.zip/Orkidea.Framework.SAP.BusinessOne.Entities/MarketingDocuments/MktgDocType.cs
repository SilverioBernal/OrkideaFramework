﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orkidea.Framework.SAP.BusinessOne.Entities.MarketingDocuments
{
    public enum MktgDocType{PurchaseOrder, Invoice, Delivery, CreditNote, DebitNote}
}
